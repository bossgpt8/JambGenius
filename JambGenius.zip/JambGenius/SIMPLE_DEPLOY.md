# Deploy JambGenius - Simple Method

Your Firebase credentials are already in the code, so deployment is super simple!

## Option 1: Netlify (Recommended)

1. **Drag & Drop:**
   - Go to [Netlify Drop](https://app.netlify.com/drop)
   - Drag your entire project folder
   - Done! Your site is live instantly

2. **Or Connect GitHub:**
   - Push to GitHub
   - Import to Netlify
   - Build settings: Leave empty (it's a static site)
   - Publish directory: `.` (root folder)

## Option 2: GitHub Pages

1. Push to GitHub
2. Settings → Pages
3. Source: Deploy from branch → `main`
4. Save

## Option 3: Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel`
3. Follow prompts

## Important: Configure Firebase

After deploying, add your live domain to Firebase:

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select "jambgenius" project
3. **Authentication** → **Settings** → **Authorized domains**
4. Click **Add domain** and add your deployment URL
   - For Netlify: `your-site.netlify.app`
   - For GitHub Pages: `yourusername.github.io`
   - For Vercel: `your-site.vercel.app`

## Test Locally

Just open `index.html` in your browser! 

But note: Google Sign-In won't work locally - it only works on authorized domains you add in Firebase Console.

## That's it! 🚀

Your website is ready to deploy. All features work:
✅ Practice Mode
✅ Exam Mode  
✅ Google Sign-In
✅ All navigation buttons
✅ No fake stats
