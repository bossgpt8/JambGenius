# Migrating to Supabase Edge Functions for Secret API Key Management

## Why Use Supabase Edge Functions?

Supabase Edge Functions provide a secure, serverless way to handle secret API keys like your `PAYSTACK_SECRET_KEY`. Unlike Netlify, Supabase integrates directly with your Firebase setup and provides:

- ✅ Built-in secret management
- ✅ Global edge deployment (faster response times)
- ✅ Direct Firestore/Firebase integration
- ✅ Free tier with generous limits

## Setup Steps

### 1. Install Supabase CLI

```bash
npm install -g supabase
```

### 2. Initialize Supabase in Your Project

```bash
# Login to Supabase
supabase login

# Initialize Supabase (creates ./supabase folder)
supabase init

# Link to your Supabase project (or create new one)
supabase link --project-ref YOUR_PROJECT_REF
```

### 3. Create the Payment Verification Edge Function

```bash
supabase functions new verify-payment
```

This creates: `./supabase/functions/verify-payment/index.ts`

### 4. Write the Edge Function

Edit `./supabase/functions/verify-payment/index.ts`:

```typescript
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST',
        'Access-Control-Allow-Headers': 'Content-Type',
      }
    })
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { 'Content-Type': 'application/json' } }
    )
  }

  try {
    const { reference, email, fullName } = await req.json()

    if (!reference) {
      return new Response(
        JSON.stringify({ error: 'Payment reference is required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Get Paystack secret from environment
    const paystackSecretKey = Deno.env.get('PAYSTACK_SECRET_KEY')
    
    if (!paystackSecretKey) {
      console.error('PAYSTACK_SECRET_KEY is not configured')
      return new Response(
        JSON.stringify({ error: 'Payment verification service not configured' }),
        { status: 500, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Verify payment with Paystack
    const verifyResponse = await fetch(
      `https://api.paystack.co/transaction/verify/${reference}`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${paystackSecretKey}`,
          'Content-Type': 'application/json',
        }
      }
    )

    const verificationResult = await verifyResponse.json()

    if (!verificationResult.status || verificationResult.data.status !== 'success') {
      return new Response(
        JSON.stringify({ success: false, error: 'Payment verification failed' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Validate payment details
    const EXPECTED_AMOUNT = 100000 // ₦1,000 in kobo
    const EXPECTED_CURRENCY = 'NGN'

    const paidAmount = verificationResult.data.amount
    const paidCurrency = verificationResult.data.currency
    const paidEmail = verificationResult.data.customer?.email || ''

    if (paidAmount !== EXPECTED_AMOUNT) {
      console.error(`Amount mismatch: expected ${EXPECTED_AMOUNT}, got ${paidAmount}`)
      return new Response(
        JSON.stringify({ success: false, error: 'Payment amount does not match. Expected ₦1,000' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    if (paidCurrency !== EXPECTED_CURRENCY) {
      console.error(`Currency mismatch: expected ${EXPECTED_CURRENCY}, got ${paidCurrency}`)
      return new Response(
        JSON.stringify({ success: false, error: 'Invalid payment currency' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    if (paidEmail.toLowerCase() !== email.toLowerCase()) {
      console.error(`Email mismatch: expected ${email}, got ${paidEmail}`)
      return new Response(
        JSON.stringify({ success: false, error: 'Payment email does not match' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Payment verified successfully
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Payment verified successfully',
        data: {
          reference: reference,
          amount: paidAmount,
          currency: paidCurrency,
          email: paidEmail,
          fullName: fullName
        }
      }),
      { 
        status: 200,
        headers: { 
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        }
      }
    )

  } catch (error) {
    console.error('Payment verification error:', error)
    return new Response(
      JSON.stringify({ success: false, error: 'Internal server error' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
})
```

### 5. Set Up Environment Variables

#### For Local Development:

Create `./supabase/.env.local`:

```bash
PAYSTACK_SECRET_KEY=sk_test_your_test_key_here
```

⚠️ **Add to .gitignore:**
```
.env.local
.env
```

#### For Production:

```bash
# Set production secret in Supabase
supabase secrets set PAYSTACK_SECRET_KEY=sk_live_your_live_key_here --project-ref YOUR_PROJECT_REF
```

### 6. Test Locally

```bash
# Start the local Supabase server with your secrets
supabase functions serve --env-file ./supabase/.env.local

# In another terminal, test the function
curl -X POST http://localhost:54321/functions/v1/verify-payment \
  -H "Content-Type: application/json" \
  -d '{"reference":"test_ref_123","email":"test@example.com","fullName":"Test User"}'
```

### 7. Deploy to Production

```bash
# Deploy the function
supabase functions deploy verify-payment --project-ref YOUR_PROJECT_REF
```

Your function will be available at:
```
https://YOUR_PROJECT_REF.supabase.co/functions/v1/verify-payment
```

### 8. Update Your Frontend Code

In `exam-payment.html`, update the payment verification URL:

```javascript
// OLD (Netlify)
const response = await fetch('/.netlify/functions/verify-payment', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ reference, email, fullName })
});

// NEW (Supabase)
const SUPABASE_PROJECT_REF = 'your-project-ref'; // Add to config.js
const response = await fetch(
  `https://${SUPABASE_PROJECT_REF}.supabase.co/functions/v1/verify-payment`,
  {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reference, email, fullName })
  }
);
```

## Benefits Over Netlify

1. **Better Integration**: Works seamlessly with Firebase/Firestore
2. **Faster**: Edge functions run closer to your users globally
3. **Cheaper**: More generous free tier (500K function invocations/month)
4. **Simpler Secrets Management**: Built-in secret management with CLI
5. **TypeScript Support**: Native Deno TypeScript support

## Managing Multiple Secrets

You can store all your API keys in Supabase:

```bash
# Add multiple secrets
supabase secrets set PAYSTACK_SECRET_KEY=sk_live_xxx
supabase secrets set FIREBASE_SERVICE_ACCOUNT_KEY=your_key_here
supabase secrets set OPENAI_API_KEY=sk-xxx

# List all secrets (shows names only, not values)
supabase secrets list
```

## Next Steps

1. Create Supabase account at https://supabase.com
2. Follow the setup steps above
3. Test locally with your Paystack test key
4. Deploy to production with your live key
5. Update frontend to use Supabase function URL
6. Remove Netlify functions folder

## Important Notes

- ⚠️ Never commit `.env` or `.env.local` files to Git
- 🔒 Always use different keys for local (test) and production (live)
- 📝 Keep your Supabase project reference in a config file
- 🌍 Supabase Edge Functions use Deno runtime (not Node.js)

## Questions?

If you need help setting this up, let me know which step you're stuck on!
