# Supabase Edge Functions Setup Guide

This guide will help you securely store and use API keys with Supabase Edge Functions for your JambGenius platform.

## Why Use Supabase Edge Functions for API Keys?

Storing API keys directly in your frontend code (like `config.js`) exposes them to anyone who visits your website. Supabase Edge Functions allow you to:

- **Keep secrets server-side**: API keys never appear in client code
- **Make secure API calls**: Your backend makes the calls, not the browser
- **Control access**: Authenticate users before allowing API access
- **Avoid CORS issues**: Server-to-server communication doesn't need CORS

## Prerequisites

1. A Supabase account (free tier works)
2. Supabase CLI installed (`npm install -g supabase`)
3. Your API keys ready (Paystack, Firebase, etc.)

## Step 1: Create a Supabase Project

1. Go to [https://supabase.com](https://supabase.com) and sign up/login
2. Click "New Project"
3. Fill in:
   - **Name**: JambGenius
   - **Database Password**: Choose a strong password
   - **Region**: Choose closest to Nigeria (e.g., Frankfurt or Singapore)
4. Click "Create new project" and wait for setup to complete

## Step 2: Initialize Supabase Locally

```bash
# Login to Supabase
supabase login

# Link your project (get project ID from Supabase dashboard)
supabase link --project-ref your-project-id

# Initialize functions directory
supabase functions new verify-payment
```

## Step 3: Set Environment Secrets

Supabase Edge Functions use environment variables for secrets. Add your API keys:

```bash
# Add Paystack secret key
supabase secrets set PAYSTACK_SECRET_KEY=your_paystack_secret_key

# Add any other API keys you need
supabase secrets set FIREBASE_SERVICE_ACCOUNT_KEY=your_firebase_key
supabase secrets set SENDGRID_API_KEY=your_sendgrid_key

# List all secrets (shows names only, not values)
supabase secrets list
```

## Step 4: Create an Edge Function

Example: Payment verification function

**File: `supabase/functions/verify-payment/index.ts`**

```typescript
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Get the payment reference from request
    const { reference } = await req.json()

    if (!reference) {
      return new Response(
        JSON.stringify({ error: 'Payment reference is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get Paystack secret key from environment (server-side only)
    const paystackSecretKey = Deno.env.get('PAYSTACK_SECRET_KEY')

    // Verify payment with Paystack
    const response = await fetch(
      `https://api.paystack.co/transaction/verify/${reference}`,
      {
        headers: {
          Authorization: `Bearer ${paystackSecretKey}`,
        },
      }
    )

    const data = await response.json()

    // Check if payment was successful
    if (data.status && data.data.status === 'success') {
      // Initialize Supabase client
      const supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? ''
      )

      // Get user from auth header
      const authHeader = req.headers.get('Authorization')!
      const token = authHeader.replace('Bearer ', '')
      const { data: { user } } = await supabaseClient.auth.getUser(token)

      if (user) {
        // Record the payment in your database
        await supabaseClient
          .from('payments')
          .insert({
            user_id: user.id,
            reference: reference,
            amount: data.data.amount / 100, // Paystack amounts are in kobo
            status: 'success',
            paid_at: data.data.paid_at
          })
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Payment verified successfully',
          data: data.data
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    } else {
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'Payment verification failed'
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
```

## Step 5: Deploy the Edge Function

```bash
# Deploy the function
supabase functions deploy verify-payment

# View function logs
supabase functions logs verify-payment
```

## Step 6: Call the Edge Function from Your Frontend

**Update your payment verification code:**

```javascript
// In your frontend JavaScript
async function verifyPayment(reference) {
  try {
    // Get current user's auth token
    const user = auth.currentUser;
    const token = await user.getIdToken();

    // Call your Supabase Edge Function
    const response = await fetch(
      'https://your-project-id.supabase.co/functions/v1/verify-payment',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ reference })
      }
    );

    const data = await response.json();
    
    if (data.success) {
      console.log('Payment verified!', data);
      // Update UI, grant access to mock exam, etc.
    } else {
      console.error('Payment verification failed:', data.message);
    }
  } catch (error) {
    console.error('Error verifying payment:', error);
  }
}
```

## Step 7: Update Your Config

**Update `config.js` to use Supabase:**

```javascript
const CONFIG = {
  firebase: {
    // Keep your Firebase config...
  },
  
  supabase: {
    url: "https://your-project-id.supabase.co",
    anonKey: "your-anon-key-here" // This is SAFE to expose
  },
  
  // Remove secret keys from config.js!
  // They're now securely stored in Supabase Edge Functions
  
  paystack: {
    publicKey: "pk_live_1ba90ace4fcc8f395ed8f0099674163e0c6dc76b" // Public key is safe
    // SECRET KEY removed - now in Supabase Edge Function
  }
};
```

## Security Best Practices

1. **Never commit secret keys to Git**
   - Add `.env` to `.gitignore`
   - Use environment variables locally
   
2. **Validate user authentication**
   - Always verify the auth token in your Edge Function
   - Check user permissions before performing actions

3. **Rate limiting**
   - Implement rate limiting in your Edge Functions
   - Prevent abuse of your API keys

4. **Error handling**
   - Don't expose sensitive error details to clients
   - Log errors server-side for debugging

## Creating Additional Edge Functions

You can create Edge Functions for any API operations:

```bash
# Send email via SendGrid
supabase functions new send-email

# Process exam results
supabase functions new process-exam-results

# Generate certificates
supabase functions new generate-certificate
```

## Testing Locally

```bash
# Serve functions locally
supabase functions serve

# Call locally (different URL)
curl -i --location --request POST 'http://localhost:54321/functions/v1/verify-payment' \
  --header 'Authorization: Bearer YOUR_AUTH_TOKEN' \
  --header 'Content-Type: application/json' \
  --data '{"reference":"test_ref_123"}'
```

## Getting Your Supabase Project URL and Keys

1. Go to your Supabase project dashboard
2. Click "Settings" in the sidebar
3. Click "API" tab
4. Copy:
   - **Project URL**: `https://xxxxx.supabase.co`
   - **Anon (public) key**: Safe to use in frontend
   - **Service role key**: NEVER expose this in frontend

## Common Issues and Solutions

### CORS Errors
- Make sure you include the CORS headers in all responses
- Handle OPTIONS requests for preflight

### Authentication Errors
- Verify the auth token is being sent correctly
- Check that the user is logged in before calling functions

### Environment Variables Not Loading
- Make sure you deployed after setting secrets: `supabase secrets set KEY=value`
- Redeploy the function after updating secrets

## Cost Considerations

Supabase Edge Functions on the free tier:
- **500,000 function invocations** per month
- **2GB function bandwidth** per month
- **500MB database storage**

For JambGenius, this should be sufficient for moderate traffic.

## Next Steps

1. Move all secret API keys from `config.js` to Supabase secrets
2. Create Edge Functions for:
   - Payment verification (Paystack)
   - Sending emails (SendGrid)
   - Any other server-side operations
3. Update your frontend code to call Edge Functions instead of making direct API calls
4. Test thoroughly before going live

## Support Resources

- [Supabase Edge Functions Docs](https://supabase.com/docs/guides/functions)
- [Deno Deploy Docs](https://deno.com/deploy/docs)
- [Supabase Community](https://github.com/supabase/supabase/discussions)

---

**Remember**: The goal is to keep all sensitive API keys server-side. Your frontend should only know about the Edge Function URL, not the actual API keys!
