# Netlify Deployment Setup for JambGenius

This guide will help you deploy the JambGenius JAMB Mock System to Netlify with all required environment variables and serverless functions.

## Prerequisites

1. A Netlify account (free tier works fine)
2. Your Paystack secret key (already provided)
3. Your reCAPTCHA secret key (already provided)
4. Firebase project credentials (already configured in config.js)

## Step 1: Connect Your Repository to Netlify

1. Log in to [Netlify](https://netlify.com)
2. Click "Add new site" → "Import an existing project"
3. Connect your Git repository (GitHub, GitLab, or Bitbucket)
4. Select your JambGenius repository

## Step 2: Configure Build Settings

In the Netlify build settings:

- **Build command**: Leave empty (this is a static site)
- **Publish directory**: `.` (root directory)
- **Functions directory**: `netlify/functions`

Click "Deploy site" (don't worry about environment variables yet)

## Step 3: Add Environment Variables

After your site is deployed, go to:
**Site settings** → **Environment variables**

Add the following environment variables:

### Required Environment Variables

| Variable Name | Value | Description |
|--------------|-------|-------------|
| `PAYSTACK_SECRET_KEY` | `sk_live_2ca27ffa9d9edf7ff00d6e94506da4492ee873cb` | Your Paystack secret key for payment verification |
| `RECAPTCHA_SECRET_KEY` | `6LdRG7QrAAAAANXU2g6OMw3kODFJ68TUDvAzgln9` | Google reCAPTCHA secret key |

### How to Add Environment Variables:

1. Click "Add a variable"
2. Select "Add a single variable"
3. Enter the variable name (e.g., `PAYSTACK_SECRET_KEY`)
4. Enter the value
5. Choose scope: **Same value for all deploy contexts** (recommended)
6. Click "Create variable"
7. Repeat for each environment variable

## Step 4: Verify Deployment

After adding environment variables:

1. Go to **Deploys** tab
2. Click "Trigger deploy" → "Clear cache and deploy site"
3. Wait for the deployment to complete

## Step 5: Test Payment Flow

1. Visit your Netlify site URL
2. Click "Take Mock Exam" button
3. Fill in payment details
4. Use Paystack test cards:
   - Success: `4084084084084081`
   - Decline: `5060666666666666666`
   - CVV: Any 3 digits
   - Expiry: Any future date
   - PIN: `1234` (if requested)

## File Structure

```
jambgenius/
├── index.html                          # Homepage
├── practice-mode-subjects.html         # Practice mode
├── exam-mode-subjects.html             # Exam mode (requires payment)
├── exam-payment.html                   # Payment page
├── config.js                          # Firebase & public API keys
├── netlify/
│   └── functions/
│       └── verify-payment.js          # Payment verification function
└── netlify.toml                       # Netlify configuration
```

## Security Notes

✅ **Public keys** (in `config.js`):
- Firebase API key
- Paystack public key
- reCAPTCHA site key

These are safe to commit to your repository.

❌ **Secret keys** (in Netlify environment variables):
- Paystack secret key
- reCAPTCHA secret key

Never commit these to your repository!

## Troubleshooting

### Payment verification fails

**Symptom**: Payment popup works but verification fails afterward

**Solution**: 
1. Check that `PAYSTACK_SECRET_KEY` is set correctly in Netlify
2. Check Netlify Function logs: Site → Functions → verify-payment
3. Ensure the function deployed correctly

### Firebase errors

**Symptom**: Authentication doesn't work

**Solution**:
1. Verify Firebase config in `config.js` matches your Firebase project
2. Enable Email/Password and Google authentication in Firebase Console
3. Add your Netlify domain to Firebase authorized domains:
   - Go to Firebase Console → Authentication → Settings
   - Add `your-site-name.netlify.app` to authorized domains

### reCAPTCHA errors

**Symptom**: reCAPTCHA doesn't load or validate

**Solution**:
1. Verify `RECAPTCHA_SECRET_KEY` is set in Netlify
2. Add your Netlify domain to reCAPTCHA allowed domains in Google reCAPTCHA admin

## Custom Domain (Optional)

To use a custom domain:

1. Go to **Domain settings** in Netlify
2. Click "Add custom domain"
3. Follow Netlify's instructions to configure DNS
4. Update authorized domains in:
   - Firebase Console
   - Google reCAPTCHA admin
   - Paystack dashboard (if needed)

## Support

If you encounter issues:

1. Check Netlify Function logs
2. Check browser console for errors
3. Verify all environment variables are set correctly
4. Contact Paystack support for payment-specific issues

## Next Steps

After deployment:

1. ✅ Test the complete payment flow
2. ✅ Test Firebase authentication
3. ✅ Test practice mode (free)
4. ✅ Test exam mode (paid)
5. ✅ Monitor Netlify Function logs for errors
6. ✅ Set up custom domain (optional)

Your JambGenius platform is now live! 🎉
