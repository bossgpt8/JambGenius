# Firestore Security Rules for JambGenius

## Important: Apply These Rules to Your Firebase Console

Go to: Firebase Console → Firestore Database → Rules

## Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // User documents - Protected exam credits
    match /users/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      
      // Allow write but restrict examCredits manipulation
      allow write: if request.auth != null && request.auth.uid == userId && (
        // Allow if examCredits is not being modified
        !request.resource.data.keys().hasAny(['examCredits']) ||
        // Or if it's being decremented by exactly 1 (exam consumption via transaction)
        (resource.data.examCredits != null && 
         request.resource.data.examCredits == resource.data.examCredits - 1) ||
        // Or if it's being incremented by exactly 1 (after payment)
        (resource.data.examCredits != null && 
         request.resource.data.examCredits == resource.data.examCredits + 1) ||
        // Or if examCredits doesn't exist yet (initial user creation)
        (resource == null || !resource.data.keys().hasAny(['examCredits']))
      );
    }

    // Exam results
    match /examResults/{resultId} {
      allow read: if request.auth != null && request.auth.uid == resource.data.userId;
      allow create: if request.auth != null && request.auth.uid == request.resource.data.userId;
      allow update, delete: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    // Chatroom messages
    match /chatMessages/{messageId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null 
                    && request.resource.data.userId == request.auth.uid
                    && request.resource.data.text is string
                    && request.resource.data.text.size() > 0
                    && request.resource.data.text.size() <= 500;
      allow delete: if request.auth != null && (
        request.auth.uid == resource.data.userId ||
        request.auth.token.email in ['osanisrael2@gmail.com', 'admin@jambgenius.com']
      );
      allow update: if false;
    }

    // Default deny all other documents
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

## What These Rules Do

### User Documents
- Users can read and write their own documents
- **Exam credits are protected**: Users can only increment or decrement by exactly 1
- This prevents users from arbitrarily setting unlimited credits

### Exam Results
- Users can only read, create, update, and delete their own exam results
- Prevents access to other users' performance data

### Chatroom Messages
- All authenticated users can read messages
- Users can only create messages with their own userId
- Messages limited to 500 characters
- Admin (osanisrael2@gmail.com) can delete any message
- Users can delete their own messages
- Messages cannot be edited (prevents tampering)

## How to Apply

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your JambGenius project
3. Click "Firestore Database" in the left sidebar
4. Click the "Rules" tab at the top
5. Replace the existing rules with the rules above
6. Click "Publish"

## Security Notes

⚠️ **Important Security Considerations:**

While these rules provide good protection, they still allow client-side credit manipulation through:
- Browser console manipulation of transactions
- Multiple rapid requests before transaction completes

### For Production Use:
Consider implementing server-side credit management using Netlify Functions or Firebase Cloud Functions:
- Move credit increment to a secure function that only runs after payment verification
- Move credit decrement to a secure function that validates before allowing exam access
- Update security rules to only allow server-side writes to `examCredits`

The current implementation is suitable for basic usage but can be improved for production security.
