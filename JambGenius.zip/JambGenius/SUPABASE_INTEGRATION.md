# Supabase Integration Guide for JambGenius

## Overview
This document explains how to integrate your Supabase database with JambGenius to load JAMB questions.

## Quick Start

### Step 1: Create Supabase Project
1. Go to [supabase.com](https://supabase.com) and create a free account
2. Create a new project
3. Wait for your database to be set up

### Step 2: Create Questions Table
In your Supabase project dashboard:
1. Go to the **SQL Editor**
2. Run this SQL to create your questions table:

```sql
CREATE TABLE questions (
  id SERIAL PRIMARY KEY,
  subject TEXT NOT NULL,  -- e.g., 'english', 'mathematics', 'physics'
  question TEXT NOT NULL,
  option_a TEXT NOT NULL,
  option_b TEXT NOT NULL,
  option_c TEXT NOT NULL,
  option_d TEXT NOT NULL,
  correct_answer TEXT NOT NULL,  -- 'A', 'B', 'C', or 'D'
  explanation TEXT,
  topic TEXT,
  difficulty TEXT  -- 'easy', 'medium', 'hard'
);
```

### Step 3: Get Your Credentials
1. In Supabase dashboard, go to **Settings** > **API**
2. Copy your **Project URL** (looks like: `https://xxxxx.supabase.co`)
3. Copy your **anon public** key (a long string starting with `eyJ...`)

### Step 4: Update config.js
Open `config.js` and replace the placeholder values:

```javascript
supabase: {
  url: "https://your-project.supabase.co",  // Replace with your URL
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."  // Replace with your key
}
```

### Step 5: Add Questions to Database
In Supabase, go to the **Table Editor** and add questions to your `questions` table, or use the SQL Editor to bulk insert:

```sql
INSERT INTO questions (subject, question, option_a, option_b, option_c, option_d, correct_answer, explanation)
VALUES 
  ('english', 'Choose the correct word: She ___ to school every day.', 'go', 'goes', 'going', 'gone', 'B', 'Use "goes" for third person singular in present tense.'),
  ('mathematics', 'Solve: 2 + 2 = ?', '2', '3', '4', '5', 'C', 'Basic addition: 2 + 2 = 4');
```

## Features

### Practice Mode (`practice.html`)
- Loads 20 questions for the selected subject
- Instant feedback after each answer
- Detailed explanations
- No time limit
- Progress tracking

### Exam Mode (`exam.html`)
- Loads 180 questions total:
  - 60 questions for Use of English
  - 40 questions each for 3 other selected subjects
- 2-hour countdown timer
- Question navigator
- Subject-wise score breakdown
- Full exam simulation

## Fallback Mode

If Supabase is not configured, both `practice.html` and `exam.html` will:
1. Show a setup alert with instructions
2. Offer to continue with sample questions
3. Work fully offline for testing purposes

This allows you to:
- Test the interface before setting up Supabase
- Develop and preview without a database
- Demonstrate the app functionality

## Integration Steps

### 1. Add Supabase Client Library
Add this to your HTML files (practice.html, exam.html):
```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
```

### 2. Initialize Supabase Client
```javascript
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
```

### 3. Fetch Questions by Subject

#### For Practice Mode (single subject):
```javascript
async function loadPracticeQuestions(subject, limit = 20) {
  const { data, error } = await supabase
    .from('questions')
    .select('*')
    .eq('subject', subject)
    .limit(limit);
  
  if (error) {
    console.error('Error loading questions:', error);
    return [];
  }
  
  return data;
}
```

#### For Exam Mode (4 subjects):
```javascript
async function loadExamQuestions(subjects) {
  // subjects = ['english', 'mathematics', 'physics', 'chemistry']
  const questions = [];
  
  // English: 60 questions
  const { data: englishQ } = await supabase
    .from('questions')
    .select('*')
    .eq('subject', 'english')
    .limit(60);
  questions.push(...englishQ);
  
  // Other 3 subjects: 40 questions each
  for (const subject of subjects.filter(s => s !== 'english')) {
    const { data } = await supabase
      .from('questions')
      .select('*')
      .eq('subject', subject)
      .limit(40);
    questions.push(...data);
  }
  
  return questions;
}
```

### 4. Randomize Questions
```javascript
function shuffleQuestions(questions) {
  return questions.sort(() => Math.random() - 0.5);
}
```

## File Structure

### Current Pages
- ✅ `index.html` - Landing page with authentication
- ✅ `practice-mode-subjects.html` - Subject selection for practice
- ✅ `exam-mode-subjects.html` - Subject selection for exam (4 subjects)
- ✅ `study-tips.html` - Study tips and strategies

### Pages Created
- ✅ `practice.html` - Practice mode question interface with instant feedback
- ✅ `exam.html` - Exam mode question interface (180 questions, 2-hour timer)
- ✅ `supabaseClient.js` - Shared helper for Supabase integration

## Subject Mapping

Match these subject values with your Supabase database:

| Display Name | Subject Code | Questions in Exam |
|-------------|--------------|-------------------|
| Use of English | `english` | 60 (mandatory) |
| Mathematics | `mathematics` | 40 |
| Physics | `physics` | 40 |
| Chemistry | `chemistry` | 40 |
| Biology | `biology` | 40 |
| Government | `government` | 40 |
| Economics | `economics` | 40 |
| Commerce | `commerce` | 40 |
| Literature in English | `literature` | 40 |
| Geography | `geography` | 40 |
| CRS | `crs` | 40 |
| Civic Education | `civic` | 40 |

## Next Steps

1. **Create Practice Interface** (`practice.html`)
   - Single subject
   - No time limit
   - Instant feedback
   - Detailed explanations

2. **Create Exam Interface** (`exam.html`)
   - 4 subjects (180 questions total)
   - 2-hour countdown timer
   - No feedback until end
   - Results screen with breakdown

3. **Add Progress Tracking**
   - Save attempts to Firebase Firestore
   - Update performance analytics
   - Track subject-specific performance

## Example Question Object
```javascript
{
  id: 1,
  subject: 'mathematics',
  question: 'What is the value of x in the equation 2x + 5 = 13?',
  option_a: '2',
  option_b: '4',
  option_c: '6',
  option_d: '8',
  correct_answer: 'B',
  explanation: 'Solving for x: 2x = 13 - 5, 2x = 8, x = 4',
  topic: 'Linear Equations',
  difficulty: 'easy'
}
```

## Security Note
- Store Supabase credentials as environment variables
- Use Row Level Security (RLS) in Supabase
- Make questions table publicly readable (no auth required for reading)
- Protect write operations
