# Google reCAPTCHA Setup Guide

## What is reCAPTCHA?
reCAPTCHA is a free security service from Google that protects your website from spam and bots by verifying that users are human.

## How to Get Your reCAPTCHA Keys

### Step 1: Go to Google reCAPTCHA Admin Console
Visit: https://www.google.com/recaptcha/admin/create

### Step 2: Register Your Site
1. **Label**: Enter a name for your site (e.g., "JambGenius")
2. **reCAPTCHA type**: Select **reCAPTCHA v2**
3. Choose: **"I'm not a robot" Checkbox**
4. **Domains**: Add your domain names:
   - For testing locally: `localhost` or `127.0.0.1`
   - For production: `yourdomain.com` (without http://)
   - For Replit: Your Replit URL domain (e.g., `your-repl-name.repl.co`)
5. **Accept the reCAPTCHA Terms of Service**
6. Click **Submit**

### Step 3: Get Your Keys
After registration, you'll receive:
- **Site Key** (Public key - goes in your HTML)
- **Secret Key** (Private key - keep this secure, use for backend verification)

### Step 4: Add Site Key to Your Website

1. Open `index.html`
2. Find this line (appears twice - once in sign-in form, once in sign-up form):
   ```html
   <div class="g-recaptcha" data-sitekey="YOUR_RECAPTCHA_SITE_KEY_HERE"></div>
   ```
3. Replace `YOUR_RECAPTCHA_SITE_KEY_HERE` with your actual Site Key

Example:
```html
<div class="g-recaptcha" data-sitekey="6LcAbCdEfGhIjKlMnOpQrStUvWxYz"></div>
```

### Step 5: (Optional) Backend Verification
For production, you should verify the reCAPTCHA response on your backend server:

```javascript
// When user submits the form, get the response token
const recaptchaResponse = grecaptcha.getResponse();

// Send to your backend for verification
fetch('/verify-recaptcha', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ recaptchaToken: recaptchaResponse })
});

// Backend verification (Node.js example)
const fetch = require('node-fetch');

async function verifyRecaptcha(token) {
    const secretKey = 'YOUR_SECRET_KEY_HERE';
    const response = await fetch('https://www.google.com/recaptcha/api/siteverify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `secret=${secretKey}&response=${token}`
    });
    
    const data = await response.json();
    return data.success; // true if verified, false if not
}
```

## Testing Your Setup

1. Save your changes
2. Open your website
3. Click "Sign In" or "Sign Up"
4. You should see the reCAPTCHA checkbox
5. Check the box - you may be asked to verify images if Google suspects bot activity
6. After successful verification, you can submit the form

## Important Notes

- **Free to use**: Google reCAPTCHA is completely free for standard use
- **Migration reminder**: All reCAPTCHA keys need to be migrated to Google Cloud Platform by end of 2025
- **Domain restrictions**: The site key only works on the domains you registered
- **Testing locally**: Add `localhost` as a domain for local testing
- **Multiple domains**: You can add multiple domains to one site key

## Troubleshooting

### reCAPTCHA not showing
- Check that the script is loaded: `<script src="https://www.google.com/recaptcha/api.js" async defer></script>`
- Verify your site key is correct
- Check browser console for errors

### "Invalid site key" error
- Make sure you're using the **Site Key**, not the Secret Key
- Verify the domain is registered in your reCAPTCHA admin console

### reCAPTCHA working but form still submits
- You need to add validation to check if reCAPTCHA is completed before allowing form submission
- Use `grecaptcha.getResponse()` to check if user completed the challenge

## Need Help?
Official Documentation: https://developers.google.com/recaptcha/docs/display
