# Deploy JambGenius to Netlify

## Quick Setup

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

### 2. Deploy to Netlify

1. Go to [Netlify](https://app.netlify.com/)
2. Click "Add new site" → "Import an existing project"
3. Connect your GitHub repository
4. Configure build settings:
   - **Build command**: `node build.js`
   - **Publish directory**: `dist`

### 3. Add Environment Variables in Netlify

Go to Site settings → Environment variables and add:

- `VITE_FIREBASE_API_KEY` = (your Firebase API key)
- `VITE_FIREBASE_PROJECT_ID` = (your Firebase project ID)
- `VITE_FIREBASE_APP_ID` = (your Firebase app ID)

### 4. Configure Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your project
3. Go to **Authentication** → **Settings** → **Authorized domains**
4. Add your Netlify domain (e.g., `your-site.netlify.app`)

## That's it! 🎉

Your site will automatically rebuild and deploy whenever you push changes to GitHub.

## Local Testing

To test the build locally:
```bash
node build.js
```

This creates a `dist/` folder with your built site.

## Security Notes

✅ **Safe**: Firebase API keys in frontend code are designed to be public
✅ **Protected by**: Firebase Security Rules and Authorized Domains
✅ **No Netlify Functions needed**: Firebase handles auth securely on the client side
